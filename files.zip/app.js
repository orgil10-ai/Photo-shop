/* ===================================================
   PixelForge — Photo Editor
   =================================================== */

const mainCanvas = document.getElementById('main-canvas');
const drawCanvas = document.getElementById('draw-canvas');
const mCtx = mainCanvas.getContext('2d');
const dCtx = drawCanvas.getContext('2d');
const dropHint = document.getElementById('drop-hint');
const canvasContainer = document.getElementById('canvas-container');

// State
let state = {
  image: null,
  imageData: null,
  history: [],
  historyIndex: -1,
  zoom: 1,
  tool: 'select',
  drawing: false,
  brushSize: 10,
  brushOpacity: 1,
  fgColor: '#1a1a2e',
  flipH: false,
  flipV: false,
  rotation: 0,
  filterActive: 'none',
  textBold: false,
  textItalic: false,
  textUnderline: false,
};

// ============================================================
// HISTORY
// ============================================================
function pushHistory() {
  if (!mainCanvas.width) return;
  const snapshot = mCtx.getImageData(0, 0, mainCanvas.width, mainCanvas.height);
  state.history = state.history.slice(0, state.historyIndex + 1);
  state.history.push(snapshot);
  state.historyIndex = state.history.length - 1;
}

function undo() {
  if (state.historyIndex <= 0) return;
  state.historyIndex--;
  mCtx.putImageData(state.history[state.historyIndex], 0, 0);
}

function redo() {
  if (state.historyIndex >= state.history.length - 1) return;
  state.historyIndex++;
  mCtx.putImageData(state.history[state.historyIndex], 0, 0);
}

// ============================================================
// LOAD IMAGE
// ============================================================
function loadImage(file) {
  const reader = new FileReader();
  reader.onload = e => {
    const img = new Image();
    img.onload = () => {
      mainCanvas.width = img.width;
      mainCanvas.height = img.height;
      drawCanvas.width = img.width;
      drawCanvas.height = img.height;
      mCtx.drawImage(img, 0, 0);
      state.image = img;
      pushHistory();
      dropHint.style.display = 'none';
      applyZoom(1);
      document.getElementById('canvas-size').textContent = `${img.width} × ${img.height}px`;
      document.getElementById('resize-w').value = img.width;
      document.getElementById('resize-h').value = img.height;
      document.getElementById('crop-w').value = img.width;
      document.getElementById('crop-h').value = img.height;
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

// ============================================================
// ZOOM
// ============================================================
function applyZoom(z) {
  state.zoom = Math.min(8, Math.max(0.05, z));
  canvasContainer.style.transform = `scale(${state.zoom})`;
  canvasContainer.style.transformOrigin = 'top left';
  document.getElementById('zoom-label').textContent = Math.round(state.zoom * 100) + '%';
}

document.getElementById('btn-zoom-in').onclick = () => applyZoom(state.zoom * 1.2);
document.getElementById('btn-zoom-out').onclick = () => applyZoom(state.zoom / 1.2);
document.getElementById('btn-fit').onclick = () => {
  const wrapper = document.getElementById('canvas-wrapper');
  const zw = (wrapper.clientWidth - 80) / mainCanvas.width;
  const zh = (wrapper.clientHeight - 80) / mainCanvas.height;
  applyZoom(Math.min(zw, zh));
};

// ============================================================
// TOOLS
// ============================================================
document.querySelectorAll('.tool-btn').forEach(btn => {
  btn.onclick = () => {
    document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.tool = btn.dataset.tool;
    drawCanvas.style.cursor = state.tool === 'brush' || state.tool === 'eraser' ? 'crosshair' :
                               state.tool === 'text' ? 'text' : 'default';
  };
});

// ============================================================
// DRAWING
// ============================================================
let lastX, lastY;

drawCanvas.addEventListener('mousedown', e => {
  if (state.tool !== 'brush' && state.tool !== 'eraser') return;
  state.drawing = true;
  const pos = getPos(e);
  lastX = pos.x; lastY = pos.y;
  dCtx.beginPath();
});

drawCanvas.addEventListener('mousemove', e => {
  const pos = getPos(e);
  document.getElementById('cursor-pos').textContent = `X: ${Math.round(pos.x)}, Y: ${Math.round(pos.y)}`;

  if (!state.drawing) return;
  if (state.tool === 'brush' || state.tool === 'eraser') {
    dCtx.globalCompositeOperation = state.tool === 'eraser' ? 'destination-out' : 'source-over';
    dCtx.globalAlpha = state.brushOpacity;
    dCtx.strokeStyle = state.fgColor;
    dCtx.lineWidth = state.brushSize;
    dCtx.lineCap = 'round';
    dCtx.lineJoin = 'round';
    dCtx.beginPath();
    dCtx.moveTo(lastX, lastY);
    dCtx.lineTo(pos.x, pos.y);
    dCtx.stroke();
    lastX = pos.x; lastY = pos.y;
  }
});

drawCanvas.addEventListener('mouseup', () => {
  if (!state.drawing) return;
  state.drawing = false;
  // Merge draw canvas onto main
  mCtx.drawImage(drawCanvas, 0, 0);
  dCtx.clearRect(0, 0, drawCanvas.width, drawCanvas.height);
  dCtx.globalCompositeOperation = 'source-over';
  pushHistory();
});

drawCanvas.addEventListener('mouseleave', () => { state.drawing = false; });

// Text tool click
drawCanvas.addEventListener('click', e => {
  if (state.tool !== 'text') return;
  const text = document.getElementById('text-input').value;
  if (!text) return;
  const pos = getPos(e);
  const size = parseInt(document.getElementById('font-size').value) || 32;
  const family = document.getElementById('font-family').value;
  const color = document.getElementById('text-color').value;
  let fontStr = `${state.textItalic ? 'italic ' : ''}${state.textBold ? 'bold ' : ''}${size}px ${family}`;
  mCtx.font = fontStr;
  mCtx.fillStyle = color;
  mCtx.fillText(text, pos.x, pos.y);
  if (state.textUnderline) {
    const w = mCtx.measureText(text).width;
    mCtx.fillRect(pos.x, pos.y + 3, w, 2);
  }
  pushHistory();
});

function getPos(e) {
  const rect = drawCanvas.getBoundingClientRect();
  return {
    x: (e.clientX - rect.left) / state.zoom,
    y: (e.clientY - rect.top) / state.zoom,
  };
}

// ============================================================
// ADJUSTMENTS
// ============================================================
const adjSliders = {
  brightness: document.getElementById('adj-brightness'),
  contrast:   document.getElementById('adj-contrast'),
  saturation: document.getElementById('adj-saturation'),
  opacity:    document.getElementById('adj-opacity'),
  temperature:document.getElementById('adj-temperature'),
};
Object.entries(adjSliders).forEach(([key, el]) => {
  el.addEventListener('input', () => {
    document.getElementById(`val-${key}`).textContent = el.value;
  });
});

document.getElementById('btn-apply-adj').onclick = () => {
  if (!mainCanvas.width) return;
  pushHistory();
  const brightness = parseInt(adjSliders.brightness.value);
  const contrast   = parseInt(adjSliders.contrast.value);
  const saturation = parseInt(adjSliders.saturation.value);
  const opacity    = parseInt(adjSliders.opacity.value) / 100;
  const temperature= parseInt(adjSliders.temperature.value);

  const imgData = mCtx.getImageData(0, 0, mainCanvas.width, mainCanvas.height);
  const d = imgData.data;

  for (let i = 0; i < d.length; i += 4) {
    let r = d[i], g = d[i+1], b = d[i+2];

    // Brightness
    r += brightness * 2.55;
    g += brightness * 2.55;
    b += brightness * 2.55;

    // Contrast
    const f = (259 * (contrast + 255)) / (255 * (259 - contrast));
    r = f * (r - 128) + 128;
    g = f * (g - 128) + 128;
    b = f * (b - 128) + 128;

    // Saturation
    const gray = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    const s = saturation / 100;
    r = r + s * (r - gray);
    g = g + s * (g - gray);
    b = b + s * (b - gray);

    // Temperature (shift red/blue channels)
    r += temperature * 1.5;
    b -= temperature * 1.5;

    d[i]   = clamp(r);
    d[i+1] = clamp(g);
    d[i+2] = clamp(b);
    d[i+3] = Math.round(d[i+3] * opacity);
  }
  mCtx.putImageData(imgData, 0, 0);
  pushHistory();
};

document.getElementById('btn-reset-adj').onclick = () => {
  Object.values(adjSliders).forEach(el => { el.value = el.id === 'adj-opacity' ? 100 : 0; });
  document.getElementById('val-brightness').textContent = '0';
  document.getElementById('val-contrast').textContent = '0';
  document.getElementById('val-saturation').textContent = '0';
  document.getElementById('val-opacity').textContent = '100';
  document.getElementById('val-temperature').textContent = '0';
};

function clamp(v) { return Math.max(0, Math.min(255, Math.round(v))); }

// ============================================================
// FILTERS (CSS + canvas pixel)
// ============================================================
const filterDefs = {
  none:      { css: '' },
  grayscale: { pixel: (r, g, b) => { const v = 0.3*r+0.59*g+0.11*b; return [v,v,v]; } },
  sepia:     { pixel: (r, g, b) => [
    Math.min(255, r*0.393 + g*0.769 + b*0.189),
    Math.min(255, r*0.349 + g*0.686 + b*0.168),
    Math.min(255, r*0.272 + g*0.534 + b*0.131),
  ]},
  invert:    { pixel: (r, g, b) => [255-r, 255-g, 255-b] },
  vintage:   { pixel: (r, g, b) => [Math.min(255,r*1.1+20), Math.min(255,g*0.9+10), Math.min(255,b*0.7)] },
  cool:      { pixel: (r, g, b) => [Math.max(0,r-20), g, Math.min(255,b+30)] },
  warm:      { pixel: (r, g, b) => [Math.min(255,r+30), g, Math.max(0,b-20)] },
  dramatic:  { pixel: (r, g, b) => {
    const g2 = 0.3*r+0.59*g+0.11*b;
    const s = 1.5, f = 1.4;
    return [clamp(f*(g2 + s*(r-g2))), clamp(f*(g2 + s*(g-g2))), clamp(f*(g2 + s*(b-g2)))];
  }},
  blur:      { css: 'blur(2px)' },
  sharpen:   { css: 'contrast(1.3) brightness(1.05)' },
};

document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.onclick = () => {
    if (!mainCanvas.width) return;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const f = btn.dataset.filter;
    state.filterActive = f;

    const def = filterDefs[f] || { css: '' };

    if (def.css !== undefined) {
      mainCanvas.style.filter = def.css;
    } else if (def.pixel) {
      mainCanvas.style.filter = '';
      applyPixelFilter(def.pixel);
    }
  };
});

function applyPixelFilter(fn) {
  if (!mainCanvas.width) return;
  pushHistory();
  const imgData = mCtx.getImageData(0, 0, mainCanvas.width, mainCanvas.height);
  const d = imgData.data;
  for (let i = 0; i < d.length; i += 4) {
    const [r, g, b] = fn(d[i], d[i+1], d[i+2]);
    d[i] = clamp(r); d[i+1] = clamp(g); d[i+2] = clamp(b);
  }
  mCtx.putImageData(imgData, 0, 0);
  pushHistory();
}

// ============================================================
// TRANSFORM
// ============================================================
document.getElementById('btn-flip-h').onclick = () => {
  if (!mainCanvas.width) return;
  pushHistory();
  const tmp = document.createElement('canvas');
  tmp.width = mainCanvas.width; tmp.height = mainCanvas.height;
  const tCtx = tmp.getContext('2d');
  tCtx.scale(-1, 1);
  tCtx.drawImage(mainCanvas, -mainCanvas.width, 0);
  mCtx.clearRect(0, 0, mainCanvas.width, mainCanvas.height);
  mCtx.drawImage(tmp, 0, 0);
  pushHistory();
};

document.getElementById('btn-flip-v').onclick = () => {
  if (!mainCanvas.width) return;
  const tmp = document.createElement('canvas');
  tmp.width = mainCanvas.width; tmp.height = mainCanvas.height;
  const tCtx = tmp.getContext('2d');
  tCtx.scale(1, -1);
  tCtx.drawImage(mainCanvas, 0, -mainCanvas.height);
  mCtx.clearRect(0, 0, mainCanvas.width, mainCanvas.height);
  mCtx.drawImage(tmp, 0, 0);
  pushHistory();
};

document.getElementById('btn-rotate').onclick = () => {
  if (!mainCanvas.width) return;
  const tmp = document.createElement('canvas');
  tmp.width = mainCanvas.height; tmp.height = mainCanvas.width;
  const tCtx = tmp.getContext('2d');
  tCtx.translate(tmp.width / 2, tmp.height / 2);
  tCtx.rotate(Math.PI / 2);
  tCtx.drawImage(mainCanvas, -mainCanvas.width / 2, -mainCanvas.height / 2);
  mainCanvas.width = tmp.width; mainCanvas.height = tmp.height;
  drawCanvas.width = tmp.width; drawCanvas.height = tmp.height;
  mCtx.drawImage(tmp, 0, 0);
  document.getElementById('canvas-size').textContent = `${mainCanvas.width} × ${mainCanvas.height}px`;
  pushHistory();
};

// Resize
const lockAspect = document.getElementById('resize-lock');
document.getElementById('resize-w').addEventListener('input', e => {
  if (lockAspect.checked && mainCanvas.width) {
    const ratio = mainCanvas.height / mainCanvas.width;
    document.getElementById('resize-h').value = Math.round(e.target.value * ratio);
  }
});
document.getElementById('resize-h').addEventListener('input', e => {
  if (lockAspect.checked && mainCanvas.height) {
    const ratio = mainCanvas.width / mainCanvas.height;
    document.getElementById('resize-w').value = Math.round(e.target.value * ratio);
  }
});

document.getElementById('btn-resize').onclick = () => {
  if (!mainCanvas.width) return;
  const nw = parseInt(document.getElementById('resize-w').value);
  const nh = parseInt(document.getElementById('resize-h').value);
  if (!nw || !nh) return;
  const tmp = document.createElement('canvas');
  tmp.width = nw; tmp.height = nh;
  tmp.getContext('2d').drawImage(mainCanvas, 0, 0, nw, nh);
  mainCanvas.width = nw; mainCanvas.height = nh;
  drawCanvas.width = nw; drawCanvas.height = nh;
  mCtx.drawImage(tmp, 0, 0);
  document.getElementById('canvas-size').textContent = `${nw} × ${nh}px`;
  pushHistory();
};

// Crop
document.getElementById('btn-crop-apply').onclick = () => {
  if (!mainCanvas.width) return;
  const x = parseInt(document.getElementById('crop-x').value) || 0;
  const y = parseInt(document.getElementById('crop-y').value) || 0;
  const w = parseInt(document.getElementById('crop-w').value) || mainCanvas.width;
  const h = parseInt(document.getElementById('crop-h').value) || mainCanvas.height;
  const imgData = mCtx.getImageData(x, y, w, h);
  mainCanvas.width = w; mainCanvas.height = h;
  drawCanvas.width = w; drawCanvas.height = h;
  mCtx.putImageData(imgData, 0, 0);
  document.getElementById('canvas-size').textContent = `${w} × ${h}px`;
  pushHistory();
};

// ============================================================
// UNDO / REDO
// ============================================================
document.getElementById('btn-undo').onclick = undo;
document.getElementById('btn-redo').onclick = redo;
document.addEventListener('keydown', e => {
  if (e.ctrlKey && e.key === 'z') { e.preventDefault(); undo(); }
  if (e.ctrlKey && e.key === 'y') { e.preventDefault(); redo(); }
  if (e.ctrlKey && e.key === 's') { e.preventDefault(); exportImage(); }
});

// ============================================================
// BRUSH CONTROLS
// ============================================================
const brushSizeEl = document.getElementById('brush-size');
const brushOpacityEl = document.getElementById('brush-opacity');
brushSizeEl.addEventListener('input', () => {
  state.brushSize = parseInt(brushSizeEl.value);
  document.getElementById('brush-size-val').textContent = state.brushSize + 'px';
});
brushOpacityEl.addEventListener('input', () => {
  state.brushOpacity = parseInt(brushOpacityEl.value) / 100;
  document.getElementById('brush-opacity-val').textContent = brushOpacityEl.value + '%';
});

// Color
document.getElementById('color-picker').addEventListener('input', e => {
  state.fgColor = e.target.value;
  document.getElementById('fg-color').style.background = e.target.value;
});
document.getElementById('fg-color').onclick = () => document.getElementById('color-picker').click();

// ============================================================
// TEXT STYLE BUTTONS
// ============================================================
['bold', 'italic', 'underline'].forEach(style => {
  document.getElementById(`btn-${style}`).addEventListener('click', function() {
    state[`text${style.charAt(0).toUpperCase() + style.slice(1)}`] ^= true;
    this.classList.toggle('active');
  });
});

// ============================================================
// FILE OPEN / DROP
// ============================================================
function openFile() { document.getElementById('file-input').click(); }
document.getElementById('btn-open').onclick = openFile;
document.getElementById('btn-open2').onclick = openFile;
document.getElementById('file-input').onchange = e => {
  if (e.target.files[0]) loadImage(e.target.files[0]);
};

const body = document.body;
body.addEventListener('dragover', e => { e.preventDefault(); body.classList.add('drag-over'); });
body.addEventListener('dragleave', () => body.classList.remove('drag-over'));
body.addEventListener('drop', e => {
  e.preventDefault();
  body.classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) loadImage(file);
});

// ============================================================
// EXPORT
// ============================================================
const qualitySlider = document.getElementById('export-quality');
qualitySlider.addEventListener('input', () => {
  document.getElementById('val-quality').textContent = qualitySlider.value + '%';
});

function exportImage() {
  if (!mainCanvas.width) return;
  const format = document.getElementById('export-format').value;
  const quality = parseInt(qualitySlider.value) / 100;
  const link = document.createElement('a');
  link.download = `pixelforge_export.${format.split('/')[1]}`;
  link.href = mainCanvas.toDataURL(format, quality);
  link.click();
}
document.getElementById('btn-export').onclick = exportImage;
document.getElementById('btn-save').onclick = exportImage;

// ============================================================
// PANEL TOGGLE
// ============================================================
document.querySelectorAll('.section-header').forEach(header => {
  header.addEventListener('click', () => {
    const id = header.dataset.toggle;
    const body = document.getElementById(id);
    body.classList.toggle('hidden');
    header.classList.toggle('collapsed');
  });
});

// ============================================================
// EYEDROPPER
// ============================================================
drawCanvas.addEventListener('click', e => {
  if (state.tool !== 'eyedropper') return;
  const pos = getPos(e);
  const pixel = mCtx.getImageData(Math.round(pos.x), Math.round(pos.y), 1, 1).data;
  const hex = `#${pixel[0].toString(16).padStart(2,'0')}${pixel[1].toString(16).padStart(2,'0')}${pixel[2].toString(16).padStart(2,'0')}`;
  state.fgColor = hex;
  document.getElementById('fg-color').style.background = hex;
  document.getElementById('color-picker').value = hex;
});

console.log('✅ PixelForge initialized');
