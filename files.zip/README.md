# ⬡ PixelForge — Зураг Засварлагч

Adobe Photoshop-той төстэй, вэб хөтөч дээр ажилладаг зураг засварлагч програм.

## ✨ Боломжууд

### 🎨 Хэрэгслүүд
- **Бийр** — Чөлөөтэй зурах, өнгө, хэмжээ тохируулах
- **Засагч** — Зурсан зүйлийг устгах
- **Текст** — Зураг дээр текст нэмэх (Bold, Italic, Underline)
- **Өнгө авагч (Eyedropper)** — Зургаас өнгө авах
- **Тайрах (Crop)** — Зургийн хэсгийг тайрах

### 🎛️ Тохируулга
- Тод байдал (Brightness)
- Тодрол (Contrast)
- Ханасан байдал (Saturation)
- Тунгалаг байдал (Opacity)
- Дулаан байдал (Temperature)

### ✨ Шүүлтүүрүүд (10+)
- Саарал (Grayscale)
- Сепиа
- Урвуу (Invert)
- Бүдгэр (Blur)
- Хурц (Sharpen)
- Хуучин (Vintage)
- Хүйтэн / Дулаан
- Гайхалтай (Dramatic)

### ⟳ Хувиргах
- Хэмжээ өөрчлөх (Resize) — харьцааг хадгалах боломжтой
- Тайрах (Crop) — X, Y, W, H оруулж тайрах
- Хэвтээ / Босоо эргүүлэх (Flip)
- 90° эргүүлэх (Rotate)

### 📤 Экспорт
- PNG, JPEG, WEBP форматаар хадгалах
- Чанар тохируулах

### 📚 Түүх
- Ctrl+Z — Буцаах (Undo)
- Ctrl+Y — Дахин хийх (Redo)
- Ctrl+S — Хадгалах

## 🚀 Хэрхэн ажиллуулах

### Арга 1: Шууд нээх
```
index.html файлыг хөтөч дээр нээнэ
```

### Арга 2: Live Server (VS Code)
```bash
# VS Code дотор Live Server extension суулгаад
# index.html дээр баруун товш → Open with Live Server
```

### Арга 3: Python HTTP Server
```bash
cd photo-editor
python3 -m http.server 8080
# http://localhost:8080 хаягаар орно
```

## 📁 Файлын бүтэц

```
photo-editor/
├── index.html    # Үндсэн HTML бүтэц
├── style.css     # Харагдах байдал (Dark theme)
├── app.js        # Логик (Canvas API)
└── README.md     # Энэ файл
```

## 🛠️ Технологи

- **Ванилла HTML/CSS/JS** — Ямар ч framework ашиглаагүй
- **Canvas API** — Зураг боловсруулалт
- **FileReader API** — Зураг уншлага
- **CSS Variables** — Dark theme систем

## 📌 Ирээдүйд нэмэх боломжтой

- [ ] Давхрага (Layers) систем
- [ ] Shape хэрэгслүүд (тэгш өнцөгт, тойрог)
- [ ] Gradient хэрэгсэл
- [ ] Magic wand / Select by color
- [ ] Clone stamp хэрэгсэл
- [ ] Blur / Sharpen бийр
- [ ] Histogram харуулах
- [ ] PSD формат дэмжлэг

## 👨‍💻 Хувь нэмэр оруулах

Pull request-ийг тавтай морил!

## 📄 Лиценз

MIT License
